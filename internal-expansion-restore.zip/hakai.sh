#!/bin/sh
###############################################################################################
# Ultros 2023 - Hakai
# githib.com/redhate/
###############################################################################################
#----------------------------------------
# Name: Expansion Restoration Script 
#
#----------------------------------------
# Description: Copy's files from "Expansions" folder on an SD card to the internal drive
#
#----------------------------------------------------------------------------------------
# Notes: 
#		ONLY WORKS FROM SD CARD
#		You have the potential to fill your internal SD card to the brim by trying to squeeze to much on the internal and the unit will hang so be careful how much you copy.
#
#----------------------------------------------------------------------------------------
# How To Use: 
#		Copy this script to the root of an SD card named HAKAI.
#		Copy your the expansions you wish to restore to a folder named "Expansions" the same way you would if you were loading them from SD.
#		Power off the MPC then plug in the SD card.
#		Power on the MPC and wait, this process may take 20 - 30 minutes or perhaps longer! So be VERY PAITENT.
#		When the transaction is complete your MPC will power itself off.
#		Remove the card only when the unit has finally powered off and it should be restored! yay
#
###############################################################################################


## Mount the sdcard
udisks --mount /dev/mmcblk1p1

## Get the disk names
DRIVE_LIST=$(lsblk -o LABEL)

## Hakai from special HAKAI labeled drive.
if [ "x$DRIVE_LIST" != "x" ]; then
	
	## loop through usb drives
	for DRIVE in $DRIVE_LIST ; do 

        ## Only allow hakai stuff to work from these specially named card
        if [ "$DRIVE" = "HAKAI" ]; then
        
			## for mpc one.
			if [ -d "/media/acvs-content" ]; then
				cp -Rp /media/$DRIVE/Expansions/* /media/acvs-content/Expansions/
				poweroff
			fi;
			## for older mpc units with no acvs-content directory
			if [ -d "/media/az01-internal-sd" ]; then
				cp -Rp /media/$DRIVE/Expansions/* /media/az01-internal-sd/Expansions/
				poweroff
			fi;
			
		fi;
		
	done;

fi;
